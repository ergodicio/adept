#include "backend.hpp"

#include <mpi.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
void mpi_check(int error) {
    if (error == MPI_SUCCESS) return;
    char message[MPI_MAX_ERROR_STRING];
    int length = 0;
    MPI_Error_string(error, message, &length);
    throw std::runtime_error(std::string(message, length));
}
struct Options {
    Grid grid;
    int steps = 20, warmup = 3;
    double dt = 0.1, acceleration = 0.2;
    bool host_mpi = false;
    std::string mode = "landau", dump;
};
int integer(const std::string& text) {
    std::size_t end;
    int result = std::stoi(text, &end);
    if (end != text.size()) throw std::runtime_error("invalid integer: " + text);
    return result;
}
double real(const std::string& text) {
    std::size_t end;
    double result = std::stod(text, &end);
    if (end != text.size() || !std::isfinite(result)) throw std::runtime_error("invalid real: " + text);
    return result;
}
Options parse(int argc, char** argv, int rank) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        std::string key = argv[i];
        if (key == "--host-mpi") { o.host_mpi = true; continue; }
        if (key == "--help") {
            if (rank == 0) std::cout
                << "vlasov_bench [--nx N] [--nv N] [--steps N] [--warmup N] [--dt D]\n"
                << "  [--mode landau|stream|accelerate|transpose] [--acceleration A]\n"
                << "  [--length L] [--vmax V] [--amplitude A] [--host-mpi] [--dump FILE]\n";
            // All ranks take the same path; finalize normally in main.
            o.mode = "help";
            return o;
        }
        if (i + 1 == argc) throw std::runtime_error("missing value for " + key);
        std::string value = argv[++i];
        if (key == "--nx") o.grid.nx = integer(value);
        else if (key == "--nv") o.grid.nv = integer(value);
        else if (key == "--steps") o.steps = integer(value);
        else if (key == "--warmup") o.warmup = integer(value);
        else if (key == "--dt") o.dt = real(value);
        else if (key == "--acceleration") o.acceleration = real(value);
        else if (key == "--length") o.grid.length = real(value);
        else if (key == "--vmax") o.grid.vmax = real(value);
        else if (key == "--amplitude") o.grid.amplitude = real(value);
        else if (key == "--mode") o.mode = value;
        else if (key == "--dump") o.dump = value;
        else throw std::runtime_error("unknown option: " + key);
    }
    return o;
}
// Times include explicit device completion, with no computation/communication
// overlap. Reduce each rank's accumulated component times with MPI_MAX later.
enum Stage { Stream, Spline, Pack, Exchange, Field, Total, StageCount };
class Stepper {
public:
    Stepper(Backend& backend, const Options& opts) : b(backend), o(opts) {}
    template<class F> void timed(Stage stage, F fn) {
        b.synchronize();
        double start = MPI_Wtime();
        fn();
        b.synchronize();
        times[stage] += MPI_Wtime() - start;
    }
    void redistribute(bool to_x) {
        if (o.grid.ranks == 1) { b.local_layout(); return; }
        timed(Pack, [&] { b.pack(to_x); });
        int count = o.grid.count() / o.grid.ranks;
        timed(Exchange, [&] {
            if (o.host_mpi) {
                auto send = b.download_send();
                std::vector<double> recv(send.size());
                mpi_check(MPI_Alltoall(send.data(), count, MPI_DOUBLE, recv.data(), count,
                    MPI_DOUBLE, MPI_COMM_WORLD));
                b.upload_received(recv);
            } else {
                mpi_check(MPI_Alltoall(b.send_buffer(), count, MPI_DOUBLE, b.recv_buffer(),
                    count, MPI_DOUBLE, MPI_COMM_WORLD));
            }
        });
        timed(Pack, [&] { b.unpack(to_x); });
    }
    void solve_field() {
        b.density();
        b.synchronize();
        if (o.host_mpi) {
            auto density = b.download_density();
            std::vector<double> global(density.size());
            mpi_check(MPI_Allreduce(density.data(), global.data(), o.grid.nx,
                MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD));
            b.upload_density(global);
        } else {
            mpi_check(MPI_Allreduce(b.density_buffer(), b.reduced_density_buffer(),
                o.grid.nx, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD));
        }
        b.field();
    }
    void step() {
        b.synchronize();
        double start = MPI_Wtime();
        if (o.mode == "stream") timed(Stream, [&] { b.stream(o.dt); });
        else if (o.mode == "transpose") { redistribute(true); redistribute(false); }
        else {
            if (o.mode == "landau") {
                timed(Stream, [&] { b.stream(0.5 * o.dt); });
                timed(Field, [&] { solve_field(); });
            }
            redistribute(true);
            timed(Spline, [&] { b.velocity(o.dt, o.acceleration, o.mode == "landau"); });
            redistribute(false);
            if (o.mode == "landau") timed(Stream, [&] { b.stream(0.5 * o.dt); });
        }
        b.synchronize();
        times[Total] += MPI_Wtime() - start;
    }
    std::array<double, StageCount> times{};
private:
    Backend& b;
    const Options& o;
};
struct Diagnostics { double mass, kinetic, field, minimum; bool finite; };
Diagnostics diagnostics(Backend& b, Stepper& stepper, const Grid& g) {
    auto f = b.download();
    double mass = 0, kinetic = 0, minimum = std::numeric_limits<double>::infinity();
    int finite = 1;
    for (std::size_t i = 0; i < f.size(); ++i) {
        int j = i / g.nx + g.rank * g.local_v();
        double v = -g.vmax + j * g.dv();
        double weight = (j == 0 || j == g.nv - 1 ? 0.5 : 1.0) * g.dv() * g.length / g.nx;
        mass += f[i] * weight;
        kinetic += 0.5 * v * v * f[i] * weight;
        minimum = std::min(minimum, f[i]);
        finite &= std::isfinite(f[i]);
    }
    double local[] = {mass, kinetic}, global[2];
    mpi_check(MPI_Allreduce(local, global, 2, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD));
    double global_min;
    int global_finite;
    mpi_check(MPI_Allreduce(&minimum, &global_min, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD));
    mpi_check(MPI_Allreduce(&finite, &global_finite, 1, MPI_INT, MPI_MIN, MPI_COMM_WORLD));
    stepper.solve_field();
    auto field = b.download_field();
    double energy = 0;
    for (double e : field) energy += 0.5 * e * e * g.length / g.nx;
    return {global[0], global[1], energy, global_min, bool(global_finite)};
}
void dump(Backend& b, const Grid& g, const std::string& path) {
    auto local = b.download();
    std::vector<double> full(g.rank == 0 ? std::size_t(g.nx) * g.nv : 0);
    mpi_check(MPI_Gather(local.data(), int(local.size()), MPI_DOUBLE, full.data(),
        int(local.size()), MPI_DOUBLE, 0, MPI_COMM_WORLD));
    if (g.rank == 0) {
        std::ofstream out(path, std::ios::binary);
        out.write(reinterpret_cast<const char*>(full.data()), full.size() * sizeof(double));
        if (!out) throw std::runtime_error("cannot write dump: " + path);
    }
}
std::string quoted(const std::string& text) {
    std::string out = "\"";
    for (char c : text) {
        if (c == '"' || c == '\\') out += '\\';
        if (c == '\n') out += "\\n";
        else out += c;
    }
    return out + '"';
}
} // namespace

int main(int argc, char** argv) {
    try {
        prepare_device_from_environment();
    } catch (const std::exception& error) {
        std::cerr << "device binding before MPI_Init: " << error.what() << '\n';
        return 1;
    }
    MPI_Init(&argc, &argv);
    MPI_Comm_set_errhandler(MPI_COMM_WORLD, MPI_ERRORS_RETURN);
    int rank = 0;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    try {
        Options o = parse(argc, argv, rank);
        if (o.mode == "help") { MPI_Finalize(); return 0; }
        Grid& g = o.grid;
        g.rank = rank;
        mpi_check(MPI_Comm_size(MPI_COMM_WORLD, &g.ranks));
        if (g.nx < 8 || g.nv < 4 || g.nx % g.ranks || g.nv % g.ranks)
            throw std::runtime_error("nx >= 8 and nv >= 4 must both be divisible by MPI ranks");
        if (g.count() > std::size_t(std::numeric_limits<int>::max()))
            throw std::runtime_error("local state exceeds this prototype's MPI int count limit");
        if (o.steps < 1 || o.warmup < 0 || o.dt <= 0 || g.vmax <= 0 || g.length <= 0 || std::abs(g.amplitude) >= 1)
            throw std::runtime_error("require steps>0, warmup>=0, dt/vmax/length>0 and |amplitude|<1");
        if (o.mode != "landau" && o.mode != "stream" && o.mode != "accelerate" && o.mode != "transpose")
            throw std::runtime_error("unknown mode: " + o.mode);
        MPI_Comm local;
        mpi_check(MPI_Comm_split_type(MPI_COMM_WORLD, MPI_COMM_TYPE_SHARED, rank, MPI_INFO_NULL, &local));
        int local_rank;
        mpi_check(MPI_Comm_rank(local, &local_rank));
        int is_head = local_rank == 0, nodes;
        mpi_check(MPI_Allreduce(&is_head, &nodes, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD));
        char hostname[MPI_MAX_PROCESSOR_NAME];
        int host_length;
        mpi_check(MPI_Get_processor_name(hostname, &host_length));
        {
            Backend backend(g, local_rank);
            std::cerr << "rank=" << rank << " host=" << std::string(hostname, host_length)
                      << " local_rank=" << local_rank << " device=" << backend.device_name() << '\n';
            Stepper stepper(backend, o);
            backend.initialize();
            for (int i = 0; i < o.warmup; ++i) stepper.step();
            // Warmup is excluded from both timings and reported physical time.
            backend.initialize();
            auto initial = diagnostics(backend, stepper, g);
            stepper.times.fill(0.0);
            backend.synchronize();
            mpi_check(MPI_Barrier(MPI_COMM_WORLD));
            for (int i = 0; i < o.steps; ++i) stepper.step();
            std::array<double, StageCount> times;
            mpi_check(MPI_Reduce(stepper.times.data(), times.data(), StageCount,
                MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD));
            auto final = diagnostics(backend, stepper, g);
            if (!initial.finite || !final.finite) throw std::runtime_error("nonfinite distribution");
            if (!o.dump.empty()) dump(backend, g, o.dump);
            std::uint64_t allocated = backend.allocated_bytes(), max_allocated;
            mpi_check(MPI_Reduce(&allocated, &max_allocated, 1, MPI_UINT64_T, MPI_MAX, 0, MPI_COMM_WORLD));
            if (rank == 0) {
                const char* names[] = {"stream_ms", "spline_ms", "pack_ms", "mpi_ms", "field_ms", "step_ms"};
                std::cout << std::setprecision(16) << "{\"backend\":"
#ifdef VLASOV_CUDA
                          << "\"cuda\""
#else
                          << "\"fftw\""
#endif
                          << ",\"device\":" << quoted(backend.device_name())
                          << ",\"precision\":\"float64\",\"mode\":" << quoted(o.mode)
                          << ",\"nx\":" << g.nx << ",\"nv\":" << g.nv << ",\"ranks\":" << g.ranks
                          << ",\"nodes\":" << nodes << ",\"steps\":" << o.steps << ",\"warmup\":" << o.warmup
                          << ",\"dt\":" << o.dt << ",\"length\":" << g.length << ",\"vmax\":" << g.vmax
                          << ",\"amplitude\":" << g.amplitude << ",\"acceleration\":" << o.acceleration
                          << ",\"host_mpi\":" << (o.host_mpi ? "true" : "false")
                          << ",\"state_bytes\":" << std::uint64_t(g.nx) * g.nv * sizeof(double)
                          << ",\"max_allocated_bytes_per_rank\":" << max_allocated;
                for (int i = 0; i < StageCount; ++i)
                    std::cout << ",\"" << names[i] << "\":" << times[i] * 1000.0 / o.steps;
                std::cout << ",\"initial_mass\":" << initial.mass << ",\"final_mass\":" << final.mass
                          << ",\"mass_relative_change\":" << (final.mass - initial.mass) / initial.mass
                          << ",\"initial_kinetic_energy\":" << initial.kinetic << ",\"final_kinetic_energy\":" << final.kinetic
                          << ",\"initial_field_energy\":" << initial.field << ",\"final_field_energy\":" << final.field
                          << ",\"minimum_f\":" << final.minimum << ",\"finite\":true}\n";
            }
        } // Destroy CUDA resources before MPI finalization.
        mpi_check(MPI_Comm_free(&local));
        MPI_Finalize();
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "rank " << rank << ": " << error.what() << '\n';
        MPI_Abort(MPI_COMM_WORLD, 1);
        return 1;
    }
}
